var cube1;
var cube2;
var cube3;
var cube4;

function setup() {
  createCanvas(400,400);
  background(51);
  box = createSprite(200,200,30,30);
  cube1 = createSprite(20,10,20,20);
  cube2 = createSprite(20,390,20,20);
  cube3 = createSprite(390,390,20,20);
  cube4 = createSprite(390,10,20,20);
}

function draw() 
{
  
  

  if (keyIsDown(LEFT_ARROW)) 
  {
    background("purple");
  }
 
    if (keyIsDown(UP_ARROW)) 
  {
    background("gold");
   
  }

  if (keyIsDown(DOWN_ARROW)) 
  {
    background("brown");
  }

  if (keyIsDown(RIGHT_ARROW)){
    background("blue");
  }


  
  drawSprites();
}

